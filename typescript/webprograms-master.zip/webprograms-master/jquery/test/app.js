(function(){
    myapp ={}
    myapp.checkName=function(str){
        // if(str.length>5)
            return str.toUpperCase();
    }
    myapp.sum = function(x,y){
        return x-y;
    }
})();