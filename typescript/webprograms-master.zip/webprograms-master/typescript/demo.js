var message = 'hello world';
console.log(message);
mes = 'welcome';
