sayHello('hello')
function  sayHello(message: string,name?:string ){
    console.log(message);
    console.log(`welcome ${name}`);
}

function sayHi( ){
    console.log(message);
    console.log(`welcome ${name}`);
}