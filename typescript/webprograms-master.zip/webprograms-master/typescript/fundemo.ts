function calcSum (n1:number,n2:number):void {
    console.log(n1+n2);
}

calcSum(10,20);
let greetUser = function (name: string){
    return 'welcome '+name;
}
console.log(greetUser('Ram'));

let greeter = (msg: string)=>{
    return msg;
}
console.log(greeter('Have a good day'));
