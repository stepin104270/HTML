
var message = "Hello world";
console.log(message);
// console.log(mes);

var value: string|number 
value = 'Ram';
console.log('welcome',value);
console.log(typeof(value));

value = 200;
console.log('val',value);
console.log(typeof(value));

var msg:any = 'hello';
msg=90;
console.log(msg);


