function calcSum(n1, n2) {
    console.log(n1 + n2);
}
calcSum(10, 20);
var greetUser = function (name) {
    return 'welcome ' + name;
};
console.log(greetUser('Ram'));
var greeter = function (msg) {
    return msg;
};
console.log(greeter('Have a good day'));
