class Trial{
	greet():void{
		console.log("welcome to TS");
	}
}
var obj = new Trial();
obj.greet();