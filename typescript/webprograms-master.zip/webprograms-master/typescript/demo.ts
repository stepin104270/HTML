declare var mes:string;
var message = 'hello world';
console.log(message);
mes = 'welcome';


