import { sumAll,divideAll } from "./13module";
console.log(sumAll(9, 8)); 
console.log(divideAll(9, 8)); 