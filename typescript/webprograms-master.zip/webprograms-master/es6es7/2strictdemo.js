"use strict";
var message=10;
console.log(message);
message="hello";
console.log(message);

var msg = "This needs a var declaration";
console.log(msg);

function greet(){
    msg = "This is a demo";
}
greet();