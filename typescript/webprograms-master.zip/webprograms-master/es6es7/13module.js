let greet=()=>  console.log("Hello World") 
export {greet};

export let msg='hello';
export let sumAll = (a, b) => {return a + b;}
export let message = 'Great day';

let divideAll = (a, b) => {return a / b;}
let multiplyAll = (a, b) => {return a * b;}
let findModulus = (a, b) => {return a % b;}

export {divideAll};
// export {sumAll, subtractAll, divideAll, multiplyAll, findModulus};